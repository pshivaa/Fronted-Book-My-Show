import React from "react";

function Footer() {
  return (
    <div className="footer">
      <h5>Movie Booking Dashboard</h5>
    </div>
  );
}

export default Footer;
